/* File: content.js
 * ---------------
 * Hello! You'll be making most of your changes
 * in this file. At a high level, this code replaces
 * the substring "cal" with the string "butt" on web pages.
 *
 * This file contains javascript code that is executed
 * everytime a webpage loads over HTTP or HTTPS.
 */

var targetDiv = document.getElementsByClassName("a-row a-size-base a-color-secondary");
var patt = new RegExp("^by\\s.*");

for (var i = 0; i < targetDiv.length; i++) {
  var currElem = targetDiv[i];
  if (patt.test(currElem.innerText)) {
    // Create a request variable and assign a new XMLHttpRequest object to it.
    var request = new XMLHttpRequest();

    // Open a new connection, using the GET request on the URL endpoint
    var company_name = currElem.innerText.slice(3);
    request.open('GET', 'https://en.wikipedia.org/api/rest_v1/page/html/' + company_name, false);
    request.setRequestHeader("Content-Type", "application/json");

    request.onload = function () {
      // Begin accessing JSON data here
      // var data = JSON.parse(this.response);
      var resp_ok_patt = new RegExp("^<!DOCTYPE html>.*");
      if (resp_ok_patt.test(this.response)) {
        var para = document.createElement("p");
        var node = document.createTextNode("Social-Good Rating: 10");
        para.appendChild(node);
        currElem.appendChild(para);
      } else {
        var para = document.createElement("p");
        var node = document.createTextNode("Social-Good Rating: None available");
        para.appendChild(node);
        currElem.appendChild(para);
      }
    }

    // Send request
    request.send();

  }
}
