from googleapiclient import discovery
import httplib2
from oauth2client.client import GoogleCredentials

import json
import re

DISCOVERY_URL = ('https://{api}.googleapis.com/'
                 '$discovery/rest?version={apiVersion}')


def main():
    http = httplib2.Http()

    credentials = GoogleCredentials.get_application_default().create_scoped(
        ['https://www.googleapis.com/auth/cloud-platform'])

    http = httplib2.Http()
    credentials.authorize(http)

    service = discovery.build('language', 'v1beta1',
                              http=http, discoveryServiceUrl=DISCOVERY_URL)

    # print(another["document"])

    #  inputfile = json.load(open("request.json"))
    #  print(type(inputfile))
    #  print
    with open('request.json', 'r') as f:
        temp_dict = json.load(f)

    service_request = service.documents().analyzeSentiment(body=temp_dict)
    contentonly = temp_dict["document"]["content"]

    def find_keywords(phrases, text):
        found = []
        text = text.lower()
        for phrase in phrases:
            phrase = phrase.lower()
            if re.findall('\\b' + phrase + '\\b', text):
                found.append(phrase)

        return (found)

    social_good_dict = ["social responsibility", "environmentally friendly", "recyclable", "awareness", "b-corporation",
                        "environmental sustainability", "corporate responsibility", "foundation", "philantrophy"]

    # for word in contentonly.split():
    # word = str(re.sub(r'[^\w\s]','',word)).lower() #get rid of punctuation
    # if word in social_good_dict and word not in keywords:
    # keywords.append(word)

    response = service_request.execute()
    polarity = response['documentSentiment']['polarity']
    magnitude = response['documentSentiment']['magnitude']
    polarityval = str(polarity)
    magnitudeval = str(magnitude)
    # print('Sentiment: polarity of ' + str(polarity) + ' with magnitude of ' + str(magnitude))
    numstars = 2.5 + polarity * 2.5
    keywords = str(find_keywords(social_good_dict, contentonly))
    # confidence = magnitude * 100
    print('Keywords for this company are: ' + keywords)
    print('Your product gets ' + str(numstars) + '/5.0 social good stars!')
    keywords_rating = (keywords, numstars)
    print(keywords_rating)
    return keywords_rating


if __name__ == '__main__':
    main()